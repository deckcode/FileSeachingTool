package FuzzySearch;

import java.io.File;
import java.util.Arrays;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;

import java.util.regex.Pattern;

import Data.FileData;

public class FuSearchFileThread extends Thread {
	private volatile  Vector<FileData> result;
	private   Pattern pattern; 
	private boolean IsSearchFileIner;
	private volatile  BlockingQueue  <Runnable> task;
	
private  volatile  Vector<File>  folders;
private Object control= new Object();
private volatile boolean IsSuspend =false;
private volatile  boolean ISEnd =false;

	
	public FuSearchFileThread(
			Vector<File>  list,
			Pattern pattern,
			Vector<FileData> result,
			boolean IsSearchFileIner,
			BlockingQueue  <Runnable> task) 
	{
		this.folders = list;
		this.result =result;
		this.pattern  = pattern;
		this.IsSearchFileIner =IsSearchFileIner;
	     this .task =task;
	     //control = new Object();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub    
	
	while(!folders.isEmpty()&&!ISEnd) {
		
		if(IsSuspend) {
		synchronized (control) {
		
				try {
				
					//System.out.println(Thread.currentThread().getId()+"       stop");
					control.wait();//�ؼ�  ���߳�wait���ͷ���
				//System.out.println(Thread.activeCount()+Thread.currentThread().getId()+"      �����̼߳���");
				
				}catch (InterruptedException e) {
					//e.printStackTrace();
				//	System.out.println("��ͣ������");
					//System.out.println(Thread.activeCount()+Thread.currentThread().getId());
					break;
				}
				
				
			}
			
		}
	
		try {
			Thread.sleep(2);
		}catch (Exception e) {
			// TODO: handle exception
			break;
		}
		
		File e ;
		try {
			 e = folders.remove(0);
		} catch (ArrayIndexOutOfBoundsException e1) {
			//System.out.println("��������");
			break;
			// TODO: handle exception
		}
		
	    //System.out.println(Thread.currentThread().getId() + "   " + e);
		//����ƥ���ϵ� �ļ��� ���� �ļ�
		if(pattern.matcher(e.getName().toLowerCase()).matches())//ȫ��ƥ��
			result.add(new FileData(e,pattern));

		else {//û��ƥ���ϵ��ļ�
			
			if(e.isFile()&&IsSearchFileIner&&e.getName().toLowerCase().endsWith(".txt")) {
						
				task.add(new SearchFileInnerTask(e, result, pattern)) ;//���ݲ���;
			}
			else if(e.isDirectory()){//�ļ���  ��������
				
				File fs [] = e.listFiles();
				if(fs!=null) folders.addAll(Arrays.asList(fs));
	
                  }

		    }
    	}
	}

public int getSize() {
	
	return folders.size();
	
}
	public void setSuspend (boolean suspend) {//mainThread���߳�ִ�и÷���
		//System.out.println(suspend);
		if(!suspend) {
			synchronized (control) {
				//System.out.print("1����   ");
				control.notify();	
				//System.out.println("����2");
			}
		}
		this.IsSuspend=suspend;
	}

	public void  setEnd(boolean end) {
		//System.out.println(this.isAlive());
		if(this.isAlive()) {
			this.ISEnd=end;
			this.interrupt();
		}
		
	}


	
}
