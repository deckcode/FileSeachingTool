package FuzzySearch;
import java.io.File;
import java.util.Arrays;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.regex.Pattern;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.plaf.metal.MetalIconFactory.FolderIcon16;

import Data.FileData;
import MainWindow.MainFrame;
import Services.ThreadManger;
import Services.Transfer;
import ViceWindow.ViceFrame;




public class fuMainThread  extends Thread {


	private   Thread  TransferThread =null;
	private volatile   Vector<FileData> result;
	private File Root;
	private  ViceFrame  frame;
	private  Pattern pattern;
	private volatile  boolean Isstop = false;
	private volatile  boolean IsSusspend = false;
	
	private Object control= new Object();
	
	
	private volatile  BlockingQueue  <Runnable> task;//�������ܴܺ�  ����������п��� ��ʱ�ʵ�����  �߳�����
	private boolean IsSearchFileInner;
	private    ThreadManger  threadManager ;
    private  Vector <File>folders;
	private MainFrame mainFrame ;
	public fuMainThread(MainFrame mainframe,Vector<FileData> result2, File root2, Pattern compile,
			boolean isSearchFileInner2, ViceFrame frame2) {
		// TODO Auto-generated constructor stub
		this.mainFrame= mainframe;
		folders = new Vector<File>();
		result=result2;
		//	System.out.println("Vector<FileData>"+e.hashCode());
			Root =root2;
			this.pattern = compile;
			this.frame =frame2;
			this.IsSearchFileInner = isSearchFileInner2;
			task = new LinkedBlockingQueue<Runnable>();
			threadManager = new ThreadManger();
			
	}

	//@SuppressWarnings("static-access")
	@Override
	public  void run() {
		//�����̷߳��������  һ���ļ�������һ���߳�

		File fs[]=Root.listFiles(); 
		
		if(fs!=null) {
         
			
			folders.addAll(Arrays.asList(fs));

			for(int i=0;i<8;i++)
		    threadManager.mexecute(new FuSearchFileThread(folders, pattern, result, IsSearchFileInner, task));

      //SearchFileThread(Pattern pattern,Vector<FileData> result, boolean IsSearchFileIner,
  	//		LinkedList<File> list,BlockingQueue  <Runnable> task)
	       TransferThread  = new Transfer(result, frame, IsSearchFileInner);
	
	       threadManager.mexecute(TransferThread);
		 
		if(IsSearchFileInner) {
			for(int i=0;i<12;i++)  //�����ļ�����  �߳�
			 threadManager.mexecute(new MyWorker(task));
			
			threadManager.SpyTask(task);
		}

		threadManager.SpyResult(result);
		threadManager.SPyFolder(folders);
//	    try {
//			Thread.sleep(16000);
//		} catch (InterruptedException e1) {
//			// TODO Auto-generated catch block
//			//System.out.println("Spyerδ��ʼ���߳̽���");
//		}
//	    //��ʼresult����������������  ʵ�ֲ�ѯ������  ����ͬ��
//	    threadManager.StartSpyer();
	//    
//	    ((Transfer)TransferThread).setSleeptime(500);
		threadManager.StartSpyer();
		
		
			while(threadManager.TFisAlive()) {

				if(Isstop) {
			    	
					threadManager.mInterrupt();
				//	break;
				}
				
            // System.out.println("folders szie "+folders.size());
                
            // System.out.println("result size "+result.size());
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					break;
				}
			}
			

		}
		  threadManager.Clear();
		//����������������
			SwingUtilities.invokeLater(new Runnable() {
	  
			@Override
			public void run() {
		    frame.CloseCounter();
		   // frame.clear();
			mainFrame.setEnd();
			System.gc();
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(null, "����$@$���","��Ϣ",JOptionPane.PLAIN_MESSAGE );
			}
		});
	
		
   }
	
	public void setStop() {
	
		Isstop =true;
	
	}

	public  void setSusspend(boolean  susspend) {
		//������  �����߳�  ʵ���̼߳�������
		threadManager.setSusspend(susspend);
	
	}
}
