package FuzzySearch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;
import java.util.regex.Pattern;

import Data.FileData;
import EncodeDetector.Ecoding2;

public class SearchFileInnerTask  implements  Runnable {

	private    volatile Vector<FileData> result;
	private   Pattern pattern;
	private File  file;
	
 public SearchFileInnerTask(File file,Vector<FileData> result , Pattern pattern) {
		// TODO Auto-generated constructor stub
		this.pattern =pattern;
		this.result = result;
		this.file = file;
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		//��ѯ����
		try( InputStreamReader re = new InputStreamReader(new FileInputStream(file),Ecoding2.getFilecharset(file))){
		//	System.out.println(file.getName()+   "          "+re.getEncoding());
			//re.read(new BufferedReader());
			  BufferedReader reader = new BufferedReader(re);
			    String strtemp;
			  while((strtemp=reader.readLine())!=null) {
				 // &&!p.matcher().find()
				  if(pattern.matcher(strtemp.toLowerCase()).matches())  {
					  
					  result.add(new FileData(file));
					  break;
				  }
				  //System.out.println(pattern.matcher(strtemp).matches());//��һ������ ����ȫ��ƥ��
				//  String d= new String(strtemp.getBytes(), Ecoding2.getFilecharset(file));
			      //System.out.println(d);
			  }
			  
			  
			  
			//  System.out.println("yes");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//�ļ��Ҳ���  �п����е��ļ�����������   �е���Ҫ����ԱȨ��  �е����ڱ���������ռ��
			//e.printStackTrace();
			//System.out.println("�ļ��Ҳ��� or  �ļ���ջ��");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		
		
		//��ȡ�ļ� ƥ��
		
		
	}

	
	
}
