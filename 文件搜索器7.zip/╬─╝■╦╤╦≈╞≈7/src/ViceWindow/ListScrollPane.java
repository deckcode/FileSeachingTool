package ViceWindow;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileOwnerAttributeView;
import java.nio.file.attribute.UserPrincipal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

import Data.FileData;
import EncodeDetector.Ecoding2;

public class ListScrollPane extends JScrollPane {

	private static JTextArea Lookfield;
	private static int  index=1;
	private static final long serialVersionUID = 7429410491570336192L;
	private JList<FileData> list;
	private static	 Border Compound ;
	private DefaultListModel<FileData> listmode;
	
	
	static {
		//复合边框  包含内部  外部边框
		Compound = BorderFactory.createCompoundBorder(
					BorderFactory.createLineBorder(Color.gray, 3, true), 
					BorderFactory.createLoweredBevelBorder());
			
	}
	
	public  static void  setLookField(JTextArea lookField2) {
		
		Lookfield =lookField2;
	}
	public  ListScrollPane() {


	 list = new JList<FileData>();
	 listmode= new DefaultListModel<FileData>();
	 listmode.addElement(new FileData(new File("C:\\Users\\lenovo\\Desktop\\java\\�ļ�������5\\src\\����˵��.txt")));

	 this.setScroll();
	this.addListener_Renderer();
	//System.out.println(listmode.getSize());
	

	
	}

public void clear() {
	listmode.clear();
	index=1;
}
	    private void setScroll() {
	 
		this.setBounds(4,12,998,898);
		this.setViewportView(list);	
		//System.out.println(list);
		this.setBorder(Compound);
		list.setModel(listmode);
		
	//	System.out.println(listmode);
       //  list.setPreferredSize(new 998,898);
	}
	
	private  void  addListener_Renderer() {

		list.setCellRenderer(new JlistRenderer());

		list.addMouseMotionListener(new MouseAdapter() { 
		
	
			private volatile int  oldindex =-1;
			@Override
			public void mouseMoved(MouseEvent e) {
                             @SuppressWarnings("unchecked")
							JList<FileData > jl=  (JList<FileData>)e.getSource();
                 //   int index=    jl.getAnchorSelectionIndex();//
               // jl.setEnabled(true);
                             

                int index = jl.locationToIndex(e.getPoint());
                //System.out.println("oldindex: "+oldindex);

                try {
                	  if ( jl.getCellBounds(index, index).contains(e.getPoint())) {
                    	  
                    	  if(oldindex!=index)   jl.setSelectedIndex(index);//设置�? 项为选中状�?? 
                           oldindex=index;
                      }
                }catch (Exception e1) {
                	JOptionPane.showConfirmDialog(null,"�����쳣","�쳣",JOptionPane.ERROR_MESSAGE);
                };
            
  
			}
		});
		
		
		list.addMouseListener(new MouseAdapter() {
		
			private SimpleDateFormat dateformat  = new SimpleDateFormat("yyyy��  MM��  dd��");
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(list.getSelectedIndex()!=-1) {
				
	
				 if(e.getButton()== e.BUTTON1&&e.getClickCount()>=2) 
				 {
				
					@SuppressWarnings("rawtypes")
					JList jl =(JList)e.getSource();
//				
			//		FileData  dataitem=(FileData) jl.getModel().getElementAt(jl.getSelectedIndex());
					FileData  dataitem=	(FileData) jl.getSelectedValue();
			
					 Runtime rt = Runtime.getRuntime();
					
					 try {
						
						 if(Desktop.isDesktopSupported()) {
									Desktop.getDesktop().open(dataitem.getFile());	
						 }
						
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						  try {
							rt.exec("cmd /c start explorer  " + dataitem.getFile());
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							SwingUtilities.invokeLater(new Runnable() {
								
								@Override
								public void run() {
									// TODO Auto-generated method stub
									JOptionPane.showConfirmDialog(null,"û��Ӧ�ó�����˲�����ָ���ļ��й�����\r\n","��Ϣ",JOptionPane.CANCEL_OPTION);
								}
							});
						} 
						
					}
					 
				
				 }
				
				 else if(e.getButton()==e.BUTTON3&&e.getClickCount()>=1) {
				
					 JList list = (JList)e.getSource();
					 FileData  dataitem  = (FileData)list.getSelectedValue();
					 
					 JPopupMenu   PopUpMenu = new JPopupMenu();
					 JMenuItem FileInfo = new JMenuItem("������Ϣ");
					 JMenuItem  CopyPath = new JMenuItem("�����ļ�·��");
					 JMenuItem CopyName = new JMenuItem("�����ļ���");
					 JMenuItem LookFile = new JMenuItem("Ԥ���ı��ļ�");
					
					 
					 
					 FileInfo.addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
					File file = dataitem.getFile();
				
					Path path = Paths.get(file+"");
					BasicFileAttributeView   FileAttributesView =Files.getFileAttributeView(path, BasicFileAttributeView.class);
					FileOwnerAttributeView  OwnerAttributes =Files.getFileAttributeView(path, FileOwnerAttributeView.class); 
					//Files.getAttribute(path,);
					BasicFileAttributes  FileAttributes = null;
					try {
						  FileAttributes  = FileAttributesView.readAttributes();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null,"�ļ���Ϣ��ȡ�쳣" ,"�쳣",JOptionPane.ERROR);
	
					}
					
				
					
					UserPrincipal owner1 =null;
					try {
						owner1= OwnerAttributes.getOwner();
						
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null,"�ļ������߻�ȡ�쳣" ,"�쳣",JOptionPane.ERROR);
					}
					
					
					String str = "<html> <font  size='4'  color='orange'> �ļ���:&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</font> <font size='3'> "+file.getName()+"</font><br>"
							+"<font  size = '4' color='orange'> ·��</font><font  size ='3'>"+file.getPath()+"</font><br>"
							+"<font size ='4'  color='orange'> ����ʱ��:&nbsp;&nbsp;&emsp;&emsp;&emsp; &emsp;&emsp;</font><font  size ='3'>"+FileAttributes.creationTime()+"</font><br>"
							+"<font size ='4'color='orange' > ���һ���޸�����:&emsp;&emsp;</font><font size ='3'>"+  FileAttributes.lastModifiedTime()+"</font><br>"
							+"<font size ='4' color='orange'> �Ƿ�����:&nbsp;&nbsp;&emsp;&emsp;&emsp; &emsp;&emsp;</font> <font  size ='3'> "+(file.isHidden()?"��":"��")+"</font><br>"
							+"<font size ='4'color='orange' > �Ƿ�ɶ�:&nbsp;&nbsp;&emsp;&emsp;&emsp; &emsp;&emsp;</font><font  size ='3'> "+(file.canRead()?"��":"��")+"</font><br>"
							+"<font size ='4' color='orange'> �Ƿ��д:&nbsp;&nbsp;&emsp;&emsp;&emsp; &emsp;&emsp;</font><font  size ='3'> "+(file.canWrite()?"��":"��")+"</font><br>"
							+"<font size ='4'color='orange' > �ļ�������:&emsp;&emsp;&emsp; &emsp;&emsp;</font><font  size ='3'> "+owner1+"</font><br>"
							+"<font size ='4'color='orange' > �ļ���С:&nbsp;&emsp;&emsp;&emsp; &emsp;&emsp;</font><font  size ='3'> "+FileAttributes.size()+" KB </font><br>"
							;
					JOptionPane.showMessageDialog(null,str, "�ļ�������Ϣ",3);
						}
					});
					 
					
					 CopyPath.addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							Clipboard clip=Toolkit.getDefaultToolkit().getSystemClipboard();
							clip.setContents(new StringSelection(dataitem.getFile().getAbsolutePath()), null);
							
						}
					});
					 
					
					 CopyName.addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							Clipboard clip=Toolkit.getDefaultToolkit().getSystemClipboard();
							clip.setContents(new StringSelection(dataitem.getFile().getName()), null);
						}
					});
					 
			
					 
					 LookFile.addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							File f = dataitem.getFile();
							Lookfield.setColumns(400);
					if(f.isFile()&&f.getName().toLowerCase().endsWith(".txt")) {
						try(InputStreamReader   of = new InputStreamReader(new FileInputStream(f), Ecoding2.getFilecharset(f))){
							BufferedReader reader =new BufferedReader(of);
							String temp;
							Lookfield.setText("");
							//Lookfield.removeAll();
							Lookfield.setLineWrap(true);
						while((temp=reader.readLine())!=null) {	
							//System.out.println(temp);
							Lookfield.append(temp+"\n");
							//System.out.println(temp);
							//System.out.println(Searchrecord.contains(temp));
						}
					
						} catch (UnsupportedEncodingException e1) {
							// TODO Auto-generated catch block
							//e1.printStackTrace();
							Lookfield.setText("�ļ�������󣬶�ȡ�쳣");
						} catch (FileNotFoundException e1) {
							// TODO Auto-generated catch block
							//e1.printStackTrace();
							Lookfield.setText("�ļ���ʧ�ܣ������ļ�����������ռ�û��߲�����");
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							//e1.printStackTrace();
							Lookfield.setText("IO�쳣");
						}

						
					}
					else Lookfield.setText("��ʱֻ�ܲ鿴txt�ļ�");
			
						}
					});
					 
					 PopUpMenu.add(LookFile);
					 PopUpMenu.add(CopyName);
					 PopUpMenu.add(CopyPath);
					 PopUpMenu.add(FileInfo);
					 PopUpMenu.show(e.getComponent(), e.getX(), e.getY());
				 }
				
			}
				
			}
			
			
		 });
		
//		list.addMouseWheelListener(new MouseWheelListener() {
//			
//			@Override
//			public void mouseWheelMoved(MouseWheelEvent e) {
//				// TODO Auto-generated method stub
//				JList jl=  (JList)e.getSource();
//           
//               int index = jl.locationToIndex(e.getPoint());
//              
//               try {
//               	  if ( jl.getCellBounds(index, index).contains(e.getPoint())) {
//                   	  
//                   	     jl.setSelectedIndex(index);//设置�? 项为选中状�??
//                     }
//               }catch (Exception e1) {
//               	JOptionPane.showConfirmDialog(null,"操作异常","异常",JOptionPane.ERROR);
//               };
//           
//			}
//		});
	
		
	}
	
	private int size =0;
	private FileData[]  arr = new FileData[400];

			public void addItem(FileData e) {
				arr[size++] =e;
				if(size==400)  {
					listmode.addAll(Arrays.asList(arr));
					size=0;
					
				}	
			}
			
		
			
			public boolean addItem2(FileData e) {
			
				if(index>=800) {
					index=1;
					return false;
				}
//				System.out.println(listmode.size());
//				System.out.println(listmode.get(1));
		      //  e.setFilID(id);
				listmode.add(index, e);
				index++;
				return true;
				
			}

}
