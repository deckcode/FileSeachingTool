package ViceWindow;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.border.Border;

import Data.FileData;


public class JlistRenderer  implements  ListCellRenderer<FileData>{
	

	static private JLabel Index ;
	static private	JLabel Picture;
	static private	JLabel FileName;
	static private	JLabel ModifyDate;
	static private	JLabel PathName;
	static private	JLabel FlieType;
	static private	JLabel FileSize_kbyte;
	static private	JLabel Author;
	static private ImageIcon FileIcon1;
	static private ImageIcon DirectoryIcon;
	@SuppressWarnings("unused")
	static private ImageIcon FileIcon2;
	static private Border  Sagborder;
	static private Border Raisedborder;
	static private Color SelectedBackCol0r;
    static private JLabel mainLabel;
    static  private JLabel  IsHidden;
	@SuppressWarnings("unused")
	static private Color SelectedFontCol0r;
	static{
		
		mainLabel =new JLabel();
		Index = new JLabel();
		FileName=	new JLabel();
		IsHidden= new JLabel();
		//ModifyDate = new JLabel();
		PathName = new JLabel();
		FlieType = new JLabel();
		FileSize_kbyte= new JLabel();
		//Author= new JLabel();
		Picture= new JLabel();
		
		
	    Raisedborder = BorderFactory.createRaisedBevelBorder();
		Sagborder=BorderFactory.createLoweredBevelBorder();
		 FileIcon1 = new ImageIcon("src/imgs/File2.PNG");
		 
		FileIcon1.setImage(FileIcon1.getImage().getScaledInstance(40, 60, Image.SCALE_SMOOTH));
		DirectoryIcon = new ImageIcon("src/imgs/Directory.PNG");
		DirectoryIcon.setImage(DirectoryIcon.getImage().getScaledInstance(40,60,Image.SCALE_SMOOTH));
		
		//FileSize_byte.setBounds(600-);
		Picture.setBounds(5,10,80,55);
		
		FileName.setBounds(80,5,750,28);
		PathName.setBounds(80,35,750,30);
		
		FlieType.setBounds(850,5,150,28);
		FileSize_kbyte.setBounds(850,35,150,30);
		IsHidden.setBounds(1020,5,80,28);
		Index.setBounds(1020, 35, 80, 28);
		//ModifyDate.setBounds(1000,5,200,28);
		//Author.setBounds(1000,35,200,380);
		
		SelectedBackCol0r = new Color(147,182,252);
		SelectedFontCol0r = new Color(249,170,83);
		//FileName.setOpaque(true);
		
		mainLabel.add(Index);
		mainLabel.add(PathName);
		mainLabel.add(FlieType);
		//mainLabel.add(ModifyDate);
		//mainLabel.add(Author);
		mainLabel.add(FileSize_kbyte);
		mainLabel.add(Picture);
		mainLabel.add(FileName);
        mainLabel.add(IsHidden);
		     //�����С����Jlabel'  ʱ���޹�����
		mainLabel.setPreferredSize(new Dimension(1200,70));//�й�����
		mainLabel.setBorder(BorderFactory.createLoweredBevelBorder());

	}


	//r   DefaultListCellRenderer�̳���JLabel  ʵ����ListREnderer
		@Override
	public Component getListCellRendererComponent(JList<? extends FileData> list,
			FileData value, int index, boolean isSelected, boolean cellHasFocus) {
		// TODO Auto-generated method stub
		


Picture.setIcon(value.isIsFile()?FileIcon1:DirectoryIcon);
IsHidden.setText(value.getIsHidden());
FileName.setText(value.getFileName());
PathName.setText(value.getPathName());
//ModifyDate.setText(value.getModifyDate());
FileSize_kbyte.setText(value.getFileSize_kbyte());
FlieType.setText(value.getFileType());
Index.setText(value.getFileID());
		
		
		//���� ѡ�е���Ⱦģʽ   

	      if(isSelected) {
	    	 //Ϊʲô  FileNAme  ����� static����   ȴ
	    	  mainLabel.setBackground(SelectedBackCol0r);
	       	//  setForeground(Color.LIGHT_GRAY);
	    	  mainLabel.setBorder(Raisedborder);
	       //	FileName.setBackground(SelectedCol0r);
	       FileName.setForeground(Color.cyan);
	       	
	      // 	PathName.setBackground(Color.LIGHT_GRAY);
	      PathName.setForeground(Color.cyan);
	       	
	      // 	FlieType.setBackground(Color.LIGHT_GRAY);
	    FlieType.setForeground(Color.cyan);
	      
	       	//FileSize_kbyte.setBackground(Color.LIGHT_GRAY);
	     FileSize_kbyte.setForeground(Color.cyan);
	       	
	     	IsHidden.setBackground(Color.LIGHT_GRAY);
	       IsHidden.setForeground(Color.cyan);
	       
	       //	Author.setBackground(Color.LIGHT_GRAY);
	 //  Author.setForeground(Color.cyan);
	   
	      }
	      else {
	    	  mainLabel.setBackground(list.getBackground());
	    	  mainLabel.setForeground(list.getForeground());
	    	  mainLabel.setBorder(Sagborder);
	      // 	FileName.setBackground(list.getBackground());
	    	FileName.setForeground(list.getForeground());
	       	
	       //	PathName.setBackground(list.getBackground());
	   	PathName.setForeground(list.getForeground());
	       	
	      // 	FlieType.setBackground(list.getBackground());
	  	FlieType.setForeground(list.getForeground());
	       	
	       //	FileSize_kbyte.setBackground(list.getBackground());
	    FileSize_kbyte.setForeground(list.getForeground());
	       	
	    IsHidden.setBackground(list.getBackground());
	    IsHidden.setForeground(list.getForeground());
	       	
	       //	Author.setBackground(list.getBackground());
	 //	Author.setForeground(list.getForeground());
	       	
	      }
	    
	      mainLabel.setEnabled(list.isEnabled());
	      mainLabel. setFont(list.getFont());
	      mainLabel. setOpaque(true);
	      
		return mainLabel;
	}

}
