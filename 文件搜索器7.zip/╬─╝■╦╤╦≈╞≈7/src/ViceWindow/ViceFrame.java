package ViceWindow;

import java.awt.Color;
import java.awt.Font;

import java.awt.Image;
import java.awt.Point;

import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.WindowConstants;
import javax.swing.border.Border;

import Data.FileData;


public class ViceFrame extends JFrame {


   /*
    * JlistScroll��װ��  listmodel  ��  listcellrenderer  λ���Ѿ����ú� ֻҪ���ӵ�ָ����ǩ�ϾͿ�����
    */
    
   
/**
	 * 
	 */
	
	private JProgressBar progressBar;
private JLabel  path;
private JLabel  RegexChar;
private JLabel  SearchMode;
private JLabel  IsSearchInner;

	
	private static int FileNum=0;
	private static int markNum=0;
	private static final long serialVersionUID = -3854438571458409665L;
   private  JLabel  FileCount;
   private JLabel   FileCount2;
   private JLabel   TimeCounter;
   private JLabel  mTimer;
private  static 	ArrayList<ListScrollPane>  Tag;
	private  ListScrollPane  ScrollPane;
	private JTabbedPane  tabPane;
	private DefaultListModel<FileData> listmode;
//private static Thread getData; 
	private JScrollPane  JtextFieldScroll;
//private ListScrollPane Jl;
	private static	 Border Compound ;
	private volatile static ViceFrame   singleinstance ;
	private  JPanel  DragBar;
	private JLabel Title;
	private JTextArea  Lookfield;
	
	private JSplitPane Splitpane;
	
	//private static JTabbedPane TabPane;

	private JButton ExitBtn ;
	private JButton NarrowBtn;
	private static Border BtnBorder;
	private JLabel   TitleIcon;
	private static ImageIcon  TIcon;
	
	private static Font txtfont;
	
	private static Border Btn2Border;
	
	private  Thread  counter;
	
		static {
		txtfont  = new Font("΢���ź�",Font.BOLD,20);
		TIcon=new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/imgs/edit_find.png").getScaledInstance(25, 30,Image.SCALE_SMOOTH));
		//���ϱ߿�  �����ڲ�  �ⲿ�߿�
		Compound = BorderFactory.createCompoundBorder(
					BorderFactory.createLineBorder(Color.gray, 3, true), 
					BorderFactory.createLoweredBevelBorder());
		BtnBorder = BorderFactory.createSoftBevelBorder(ERROR, Color.gray, Color.blue);
		Btn2Border = BorderFactory.createSoftBevelBorder(ERROR,Color.LIGHT_GRAY,Color.black.red);
	}
	
	
	/**
	 * @return the singlinstance
	 */
	public static ViceFrame getSinglinstance() {
		if (singleinstance!= null) 
			{
			
			    singleinstance.setExtendedState(NORMAL);
			    try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    singleinstance.show();
			   
			     return singleinstance;
			}
		else 
			{
			 //System.out.println(singleinstance);
		    try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			     singleinstance  =new ViceFrame() ;
			     singleinstance.show();
			    return  singleinstance;
			}
	
	}

	
private  ViceFrame() {
		
		//���� UI����
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	SwingUtilities.updateComponentTreeUI(this);
	
	path =new JLabel();
	RegexChar = new JLabel();
	SearchMode = new JLabel();
	IsSearchInner = new JLabel();
	
	
	TitleIcon = new JLabel();
	Title =new JLabel(" �� �� �� �� ");
	//ScrollPane= new ListScrollPane2();
	//listmode = ScrollPane.getlistmodel();
	/*
	 * ��ҷ�и����ķָ���ʱ�������ڵ�����Ƿ�����ŷָ��ߵ���ҷ����̬�ı��С   false����
	 */
	Splitpane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,true);
	Tag = new ArrayList<ListScrollPane>();
	Lookfield = new JTextArea();
	JtextFieldScroll = new JScrollPane();
	
	tabPane= new JTabbedPane(JTabbedPane.LEFT);
	
	DragBar =new JPanel();
	
	ExitBtn= new JButton("x");
	NarrowBtn = new JButton("��");
	progressBar  = new JProgressBar();
	
	FileCount = new JLabel("�ļ�����");
	FileCount2 = new JLabel();
	mTimer = new JLabel("��ʱ���룩");
	TimeCounter = new JLabel();
	 setFrame();
	addListener();
	
}
	
	private void setFrame() {
		this.setTitle("��������");
		this.getContentPane().setBackground(Color.lightGray);
		
		
		
		TitleIcon.setIcon(TIcon);
		TitleIcon.setBounds(7,0,25,30);
		Title.setFont(txtfont);
		Title.setForeground(Color.cyan);
		Title.setBounds(40,5,150,20);
		
		path.setBounds(25,30,600,20);
		RegexChar.setBounds(700,30,200,20);
		SearchMode.setBounds(1100,30,200,20);
		IsSearchInner.setBounds(1400,30,200,20);
		

		DragBar.setLayout(null);
		NarrowBtn.setForeground(Color.blue);
		ExitBtn.setForeground(Color.red);
		ExitBtn.setBorder(Btn2Border);
		NarrowBtn.setBorder(BtnBorder);
		ExitBtn.setBounds(1551,0,50,25);
		NarrowBtn.setBounds(1503,0,50,25);
		DragBar.setBounds(0,0,1602,30);
		
		tabPane.setBounds(2,8,1000,900);
		tabPane.setBorder(Compound);
		
//		Scroll_list[0].setBounds(4,12,998,898);
//		Scroll_list[0].setViewportView(list);	
//		Scroll_list[0].setBorder(Compound);
//		
		
        Tag.add(new ListScrollPane());
        //�� Lookfield���󴫵ݸ� ListScrollPane  ��������
		ListScrollPane.setLookField(Lookfield);
		//Lookfield.set
		JtextFieldScroll.setBounds(4,10,200,900);
		JtextFieldScroll.setViewportView(Lookfield);
		JtextFieldScroll.setBorder(Compound);
		Lookfield.setBounds(10,20,300,900);

		//�� ���Scroll�����ڲ������װ������
		tabPane.addTab("0",Tag.get(markNum));
		
		
		Splitpane.setLeftComponent(tabPane);
		//ScrollPane.addItem(new FileData(new File("C:\\mysql-8.0.17-winx64\\my.ini"),"i"));
		Splitpane.setRightComponent(JtextFieldScroll);
		Splitpane.setBounds(10,60,1560,910);
		Splitpane.setBorder(BorderFactory.createLoweredBevelBorder());
		
		DragBar.add(TitleIcon);
		DragBar.add(Title);
		DragBar.add(ExitBtn);
		DragBar.add(NarrowBtn);
		DragBar.setBorder(BorderFactory.createRaisedBevelBorder());
	//ExitBtn.setBorder(BorderFactory.createRaisedBevelBorder());
	//NarrowBtn.setBorder(BorderFactory.createRaisedBevelBorder());
		
		/*
		 * ������ܵ�Splitpane �Ĵ�С  ������߷ִ��ڴ�С
		 * ����Splitpane�м�ָ��� �Ƿ��������
		 */
		
	//Splitpane.setDividerLocation(0.75);
	Splitpane.setOneTouchExpandable(true);
setIconImage(Toolkit.getDefaultToolkit().getImage("src/imgs/edit_find.png"));

FileCount.setBounds(25,1020,100,20);
FileCount2.setBounds(90,1020,100,20);
mTimer.setBounds(200,1020,100,20);
TimeCounter.setBounds(300,1020,200,20);

progressBar.setBounds(25,980,1550,40);
progressBar.setValue(2);

add(RegexChar);
add(SearchMode);
add(IsSearchInner);
add(path);

add(progressBar);
add(mTimer);
add(TimeCounter);
add(DragBar);
add(Splitpane);
add(FileCount);
add(FileCount2);


this.setUndecorated(true);
setLayout(null);	
setVisible(true);
setSize(1600,1040);
setShape(new RoundRectangle2D.Double(0d,0d,getWidth(),getHeight(),50,50));
setOpacity(0.9f);
setLocationRelativeTo(null);
setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

	}
	
	
	
	class Counter extends Thread{
		int i=0;
		private  volatile  boolean IsSusspend =false;
		private Object control= new Object();
	private  volatile boolean ISEND =false;
	
		public void run() {
			// TODO Auto-generated method stub
			int i=0;
			while(!ISEND) {
				
				if(IsSusspend) {
					synchronized (control) {
						try {
							control.wait();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						    //JOptionPane.showMessageDialog(singleinstance,"Counter����ͣ������","��Ϣ",JOptionPane.ERROR_MESSAGE);
						    break;
						}
					}
				}
				
			try {
					Thread.sleep(1000);
				     } catch (InterruptedException e) {
					// TODO Auto-generated catch block
				//	JOptionPane.showMessageDialog(null,"Counter����","��Ϣ",JOptionPane.PLAIN_MESSAGE);
					break;
				   }
				
				FileCount2.setText(FileNum+"");
				TimeCounter.setText(i+++"");
				progressBar.setValue(i%101);
			}
	
		}
		
		public  void  SetSusspend(boolean Susspend) {
			if(!Susspend) {
				synchronized (control) {
					control.notify();
					
				}
			}
			this.IsSusspend=Susspend;
		}
		
		public void setEnd(boolean end) {
			this.ISEND=end;
			this.interrupt();
		}
		
	}
	
	
	public void notifyCounter() {	
		((Counter)counter).SetSusspend(false);
	}
	
public  void SusspendCounter() {
	((Counter)counter).SetSusspend(true);
}

//��������ʱ��  ����Counter
	public void CloseCounter() {
		((Counter)counter).setEnd(true);
		FileNum=0;
		progressBar.setValue(100);
	}
	
	
	
	public void CounterStart(String paths,String patterns,String Searchmodes,String IsSearchInners) {
		//�߳̽�������������   ���Դ����µ��߳�
		counter= new Counter();
		 counter.start();
		 path.setText("<html><font > · ��</font>"+"<font color ='purple'>"+paths+"</font>");
		 RegexChar.setText("<html><font >�� �� �ʣ�</font>"+"<font color ='purple'  >"+patterns+"</font>");
		 SearchMode.setText("<html><font >�� �� ģ ʽ</font> "+"<font color ='purple'>"+Searchmodes+"</font>");
		 IsSearchInner.setText("<html><font >�Ƿ������ļ�����</font>"+"<font color ='purple'>    "+IsSearchInners+"</font>");
 
	}
	
	//����ǰ �����������
	public void clear(){
	
		for(ListScrollPane e:Tag) {
			e.clear();
		}
		Tag.clear();
		markNum=0;
		tabPane.removeAll();
		Lookfield.removeAll();
	//	Lookfield.removeAll();
		//��һ��������׼��
		Tag.add(new ListScrollPane());
		tabPane.addTab("0",Tag.get(markNum));
		singleinstance.repaint();
		
	}
	private void addListener() {
		
		//singleinstance ����  this���У�
		BtnMouseMotionListener  listener = new BtnMouseMotionListener(this);
		DragBar.addMouseListener( listener);
		DragBar.addMouseMotionListener(listener);
		
		ExitBtn.addMouseListener(new BtnMouseMotionListener(this));
		NarrowBtn.addMouseListener(new BtnMouseMotionListener(this));
		
		ExitBtn.addMouseMotionListener(new BtnMouseMotionListener(this));
		NarrowBtn.addMouseMotionListener(new BtnMouseMotionListener(this));
	}
	
	public void AddElement2(FileData d) {
		
		  FileNum++;
		  d.setFilID(FileNum);
		if(Tag.get(markNum).addItem2(d)==false) {
			markNum++;
			ListScrollPane newScroll = new ListScrollPane();
			Tag.add(newScroll);
			tabPane.addTab(""+markNum, newScroll);
			Tag.get(markNum).addItem2(d);
		}
		
		
		
	}
	

	
	
public  void addElement( FileData e) {
	
        ScrollPane.addItem(e);
  }

}
class  BtnMouseMotionListener extends  MouseAdapter{
	private static Color BtnColro;
	//oldpointһ��Ҫ����Ϊ  static��  addMouseListener ��pressed��Ӧ����  addMouseMotionListener   Draged��Ӧ����   ����һ��  oldpoint
	//����  static  �͹���һ��������Ӧlistener�ÿ���  ���ǽ����  �϶����� �������  ��֪��ô��     ʹ��Volatile�������staticЧ������  ���Ʊ������ڶ�oldpoint����������
	//�Ż���  
	/*
	 * ������Ϊvolatile�ı�����˵��������ܻᱻ���벻���ظı䣬�������������Ͳ���ȥ�������������ֵ�ˡ���ȷ��˵���ǣ�
	 * 	�Ż������õ��������ʱ����ÿ�ζ�С�ĵ����¶�ȡ���������ֵ��������ʹ�ñ����ڼĴ�����ı��ݡ�
	 */

	private volatile   Point oldpoint;
	
	static {
	
		BtnColro   = new Color(214,217,223);
	}
	private static JFrame frame ;
	//����������  ������JFrame  �ڼ������� �� JFrame����
	public BtnMouseMotionListener(JFrame frame) {
		this.frame = frame;
	}
	
	
	
	@Override
	public void mousePressed(MouseEvent e) {
		//System.out.println("pressed�¼�");
		 oldpoint = e.getPoint();
		  //  System.out.println(oldpoint.x);
		 Object ob = e.getSource();
//		 if(ob instanceof JButton) {
//			   JButton btn =(JButton) ob;
//			   btn.setBorder(BorderFactory.createLoweredSoftBevelBorder());
//		 }
	}
	@Override
	public void mouseClicked(MouseEvent e) {
	     
	  Object ob = e.getSource();
		 if(ob instanceof  JButton) {
			   JButton btn =(JButton) ob;
			   
			   if(btn.getText().equals("x")&&e.getClickCount()==1)
			   {
				
				   try {
					   if(JOptionPane.OK_OPTION==JOptionPane.showConfirmDialog(frame, " ȷ �� Ҫ �� �� �� ? ", "����", JOptionPane.OK_CANCEL_OPTION))
						    System.exit(0);
				   }catch(NullPointerException e1) {}
					  		
			    
			   }		   
              if(btn.getText().equals("��")&&e.getClickCount()==1) {
            	  frame.setExtendedState(JFrame.ICONIFIED);
            	
              }
		}
	}
	
	
	
	
	//��ק�¼�   ��  �����     ������    ����   ���Ե��û�д��¼�����
	@Override
	public void mouseDragged(MouseEvent e) {
		//������ק ����ǰ(��¼�����cursor����)��(�϶�e��������)����֮��ľ���仯   ����λ�ü�������仯���� ���
		int left =  frame.getLocation().x;  
		int top = frame.getLocation().y;
//	System.out.println("oldpoint  "+oldpoint);
//	System.out.println("new  "+e.getPoint());
//	System.out.println("��ק�¼�");
		try {
 
			
			frame.setLocation(left+e.getX()-oldpoint.x,top+e.getY()-oldpoint.y);
	
			
		}catch (NullPointerException e1) {}
			
	//	System.out.println(frame.getLocation().getX()+"         "+e.getPoint().getX());
				
	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		
		Object ob = e.getSource();
		if(ob instanceof  JButton) {
			   JButton btn =(JButton) ob;
			   if(btn.getText().equals("x"))
			   {
				   btn.setBackground(Color.RED);
				   btn.setForeground(Color.white);
				
			   }
			   
			   else  {
				   btn.setBackground(Color.blue);
				   btn.setForeground(Color.white);
				
			   }
		}
		
	}
	
	@Override
	public void mouseExited(MouseEvent e) {
	
		Object ob = e.getSource();
		if(ob instanceof  JButton) {
			   JButton btn =(JButton) ob;
			   if(btn.getText().equals("x"))
			   {
				   btn.setBackground(BtnColro);
				   btn.setForeground(Color.red);
				  // btn.setBorder(BorderFactory.createLineBorder(Color.blue,1,true));
				//   btn.setBorder(BorderFactory.createRaisedBevelBorder());
			   }
			   
			   else {
				   btn.setBackground(BtnColro);
				   btn.setForeground(Color.blue);
				 //  btn.setBorder(BorderFactory.createLineBorder(Color.red,1,true));
				  // btn.setBorder(BorderFactory.createRaisedBevelBorder());
			       }
			   }
		}
		
   

}


