package AbsoluteSearch;
import java.io.File;
import java.util.Arrays;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import Data.FileData;
import MainWindow.MainFrame;
import Services.ThreadManger;
import Services.Transfer;
import ViceWindow.ViceFrame;



public class abMainThread  extends Thread {

	private   Thread  TransferThread =null;
	private volatile   Vector<FileData> result;
	private File Root;
	private  ViceFrame  frame;
	private  String  keychar;
	private volatile boolean Isstop =false;
	private volatile  boolean IsSusspend = false;
	
	private Object control= new Object();
	
	private Vector<File>folders;
	//private BlockingQueue  <Runnable> task;//�������ܴܺ�  ����������п��� ��ʱ�ʵ�����  �߳�����
	private    ThreadManger  threadManager ;
private boolean IsSearchFileInner;
private MainFrame  mainframe;
	public abMainThread(MainFrame mainframe ,Vector<FileData> result2, File root2, String  keychar, ViceFrame frame2,boolean IsSearchFileInner) {
		// TODO Auto-generated constructor stub
		this.mainframe = mainframe;
		folders = new Vector<File>();
		result=result2;
		//	System.out.println("Vector<FileData>"+e.hashCode());
			Root =root2;
			this.keychar = keychar;
			this.frame =frame2;
			//task = new LinkedBlockingQueue<Runnable>(6000);
			threadManager = new ThreadManger();
		
			this.  IsSearchFileInner =   IsSearchFileInner;
	}

	//@SuppressWarnings("static-access")
	public  void run() {
		//�����̷߳��������  һ���ļ�������һ���߳�

		File fs[]=Root.listFiles(); 
		
		if(fs!=null) {

			folders.addAll(Arrays.asList(fs));

			for(int i=0;i<16;i++)
		    threadManager.mexecute(new AbSearchFileThread(folders, keychar, result));

	         TransferThread  = new Transfer(result, frame,IsSearchFileInner);
	
	           threadManager.mexecute(TransferThread);
              threadManager.SpyResult(result);
            	//threadManager.SPyFolder(folders);
//		   try {
//				Thread.sleep(5000);
//			} catch (InterruptedException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//		    
//		    threadManager.StartSpyer();
//		
   
        		while(threadManager.TFisAlive()) {

    				if(Isstop) {
    					threadManager.mInterrupt();
    				//	break;
    				}

             //    System.out.println("folders szie "+folders.size());
                 // System.out.println("result size "+result.size());
    				try {
    					Thread.sleep(5000);
    				} catch (InterruptedException e) {
    					// TODO Auto-generated catch block
    					//e.printStackTrace();
    					break;
    				}
    			}
    			
		
		//  threadManager.CloseSpyer();
		  threadManager.Clear();
		  
		//��������
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				frame.CloseCounter();
				// frame.clear();
				mainframe.setEnd();
				System.gc();
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(frame, "������β����$@$���","��Ϣ",JOptionPane.PLAIN_MESSAGE );
			}
		});
		
		}
  }
	
	public void setStop() {
		//System.out.println("end");
		this. Isstop = true;
	
	}

	public  void setSusspend(boolean  susspend) {
		//������  �����߳�  ʵ���̼߳�������
		threadManager.setSusspend(susspend);
	
	}

	}

