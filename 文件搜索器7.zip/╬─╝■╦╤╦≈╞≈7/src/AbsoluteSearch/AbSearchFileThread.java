package AbsoluteSearch;

import java.io.File;
import java.util.Arrays;
import java.util.Vector;

import Data.FileData;

public class AbSearchFileThread extends Thread {
	private volatile  Vector<FileData> result;
	private   String keychar; 
	private boolean IsSearchFileIner;
	
private volatile   Vector<File>    folders;
private Object control= new Object();
private volatile  boolean IsSuspend =false;
private volatile  boolean ISEnd =false;

	
	public AbSearchFileThread(
		Vector<File>  list,
			String keychar,
			Vector<FileData> result) 
	{
		this.folders = list;
		this.result =result;
		this.keychar  = keychar;
	
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub    

	while(!folders.isEmpty()&&!ISEnd) {
		if(IsSuspend) {
		synchronized (control) {	
				try {
					//System.out.println("�����߳���ͣ"+control.hashCode());	
					control.wait();//�ؼ�  ���߳�wait���ͷ���
					//System.out.println("�����̼߳���"+Thread.currentThread().getName());
				}catch (InterruptedException e) {
					break;
				}

			}
			
		}
	
		File e ;
		//System.out.println(folders.size());
		try {
			 e = folders.remove(0);
		} catch (ArrayIndexOutOfBoundsException e1) {
			//System.out.println("��������");
			break;
			// TODO: handle exception
		}
		//����ƥ���ϵ� �ļ��� ���� �ļ�
		if(keychar.toLowerCase().equals(e.getName().trim().toLowerCase()))
			result.add(new FileData(e));

		else if(e.isDirectory()) {
	
				File fs [] = e.listFiles();
				if(fs!=null) folders.addAll(Arrays.asList(fs));
	    }
		
    	}
	}


	public void setSuspend (boolean suspend) {
		if(!suspend) {
			synchronized (control) {
				control.notify();	
			}
		}
		this.IsSuspend=suspend;
	}

	public void  setEnd(boolean end) {
		if(this.isAlive()) {
			//System.out.println("end3");
			this.ISEnd=end;
			this.interrupt();
		}
		
	}


	
}
