package Services;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import Data.FileData;
import ViceWindow.ViceFrame;


public class Transfer  extends  Thread {

	private volatile  boolean ISEND =false;
	private   Vector<FileData> Resources;
	private boolean IsSearchFileInner;
	private volatile boolean Issusspend =false;
	private Object control= new Object();
     private  String keychar;
     private volatile int Sleeptime = 2000;//��λ����
	private    ViceFrame frame;
	public Transfer(Vector <FileData> e,ViceFrame frame,boolean IsSearchFileInner) {
		this.Resources=e;
		this.frame =frame;
		ISEND =false;
		this.IsSearchFileInner= IsSearchFileInner;

		//listmodel=getListmodel();
	}
	
	
	public void setSleeptime(int time) {
		Sleeptime =time;
	}
	
	
	
	
	
	
	
	/*
	 * ���¼����̫��  ��Jlist���ӵ������ֶ�  ����Ῠ��
	 * һ��jlist���ӵ�����̫�� ����Ҳ�Ῠ��
	 * 
	 * ����  ÿ��2������50 ������  û500һ��jlist  ͬʱJlist��������ʱ ��listmodel��β��  ����jlist�䶯��С ����ˢ�¸���
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		if(Resources==null)  return ;
		
			
			if(!IsSearchFileInner) {
				
				while(!ISEND) {
					
					//�жϲ�ѯ�߳��Ƿ�����߳�
				//	while();
					
//					if(Issusspend) {
//						synchronized (control) {
//						//������  �����߳�  ʵ���߳���ͣ
//							try {
//								//System.out.println("Transfer��ͣ2");
//								control.wait();
//							//	System.out.println("Transfer����2");
//							} catch (InterruptedException e) {
//								// TODO Auto-generated catch block
//								SwingUtilities.invokeLater(new Runnable() {
//									
//									@Override
//									public void run() {
//										// TODO Auto-generated method stub
//										JOptionPane.showMessageDialog(null, "�����߳���ͣ������","��Ϣ",JOptionPane.PLAIN_MESSAGE );
//									}
//								});
//
//								break;
//							}
//						}
//					}
					
					
					while(!Resources.isEmpty()) 
					{
					/////////////////////////////////////////////////////////////////	
						if(Issusspend) {
							synchronized (control) {
							//������  �����߳�  ʵ���߳���ͣ
								try {
									//System.out.println("1Transefer�߳���ͣ");
									control.wait();
									//System.out.println("1Transefer�̻߳���");
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									SwingUtilities.invokeLater(new Runnable() {
										
										@Override
										public void run() {
											// TODO Auto-generated method stub
											JOptionPane.showMessageDialog(null, "�����߳���ͣ������","��Ϣ",JOptionPane.PLAIN_MESSAGE );
											
										}
									});
									break;
									
								}
							}
						}
				///		//////////////////////////////////////////////////////
						try {
							Thread.sleep(Sleeptime);
							
							  SwingUtilities.invokeLater(new Runnable() {
									public void run() {
										// TODO Auto-generated method stub
	                                         	   for(int i=0;i<40&&!Resources.isEmpty();i++) {
	        										   FileData e =Resources.remove(0);
	        										   //System.out.println("����"+e+ "   "+Resources.size());
	        										  frame.AddElement2(e);
	                                         		 
	                                            }
											}
								});
							
							
							
							
							
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							
							SwingUtilities.invokeLater(new Runnable() {
								
								@Override
								public void run() {
									// TODO Auto-generated method stub
									JOptionPane.showMessageDialog(null,"ת���߳̽���","��Ϣ",JOptionPane.PLAIN_MESSAGE);
								}
							});
							break;
						}
						
			//	/////////////////////////////////////////////////////////////////////		
						 
					}
					//���� isempty  ��ȴ�2���ڿ�ʼ����
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e2) {
						// TODO Auto-generated catch block
						//e2.printStackTrace();
						break;
					}
					
			}
		///		/////////////////////////////////////////////////////
					SwingUtilities.invokeLater(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						JOptionPane.showMessageDialog(null,"��������","��Ϣ",JOptionPane.PLAIN_MESSAGE);
					}
				});
			}
			
			
			
			else {
				
				
				while(!ISEND) {
					
					
//					if(Issusspend) {
//						synchronized (control) {
//						//������  �����߳�  ʵ���߳���ͣ
//							try {
//								control.wait();
//							} catch (InterruptedException e) {
//								// TODO Auto-generated catch block
//								SwingUtilities.invokeLater(new Runnable() {
//									
//									@Override
//									public void run() {
//										// TODO Auto-generated method stub
//										JOptionPane.showMessageDialog(null, "�����߳���ͣ������","��Ϣ",JOptionPane.PLAIN_MESSAGE );
//									}
//								});
//								
//					               break;
//							}
//						}
//					}
					
					
					while(!Resources.isEmpty()) {
						//////////////////////////////////////////////////////////////
						if(Issusspend) {
							synchronized (control) {
							//������  �����߳�  ʵ���߳���ͣ
								try {
									control.wait();
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									SwingUtilities.invokeLater(new Runnable() {
										
										@Override
										public void run() {
											// TODO Auto-generated method stub
											JOptionPane.showMessageDialog(null, "�����߳���ͣ������","��Ϣ",JOptionPane.PLAIN_MESSAGE );
										}
									});
									
							
									break;
								}
							}
						}
						
						
						//////////////////////////////////////////////////////////////
						try {
							
							Thread.sleep(Sleeptime);
							
							 SwingUtilities.invokeLater(new Runnable() {

									public void run() {
										// TODO Auto-generated method stub
	                                   	   for(int i=0;i<40&&!Resources.isEmpty();i++) {
	  										   FileData e =Resources.remove(0);
	  										  frame.AddElement2(e);
	                                      }
									}

								});

						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
	                         SwingUtilities.invokeLater(new Runnable() {
								
								@Override
								public void run() {
									// TODO Auto-generated method stub
									
									JOptionPane.showMessageDialog(null,"ת���߳̽���","��Ϣ",JOptionPane.PLAIN_MESSAGE);
								}
							});
						
							break;
						}
						
						///////////////////////////////////////////////////////////
						  						
					}
							  
					//���� isempty  ��ȴ�2���ڿ�ʼ����
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e2) {
						// TODO Auto-generated catch block
						//e2.printStackTrace();
						break;
					}
			
					}
				
			////////////////////////////////////	
				SwingUtilities.invokeLater(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						//frame.CloseCounter();
						JOptionPane.showMessageDialog(null,"��������","��Ϣ",JOptionPane.PLAIN_MESSAGE);
					}
				});
				
			}
			
		//	System.out.println("����ת���߳�����");
		
	}

	public void setSusspend(boolean  susspend) {
		//������  �����߳�  ʵ���̼߳�������
		if(!susspend) {
			synchronized (control) {
			control.notify();	
			}	
			}
		
		 this.Issusspend=susspend;
	
	}
	
	public void  setEnd(boolean end) {

		if(this.isAlive()) {
			this.ISEND=end;
			this.interrupt();
		}
		
	}

	
}
