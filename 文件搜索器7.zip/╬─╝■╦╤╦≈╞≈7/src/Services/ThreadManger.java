package Services;

import java.io.File;
import java.util.ArrayList;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import AbsoluteSearch.AbSearchFileThread;
import Data.FileData;
import FuzzySearch.FuSearchFileThread;
import FuzzySearch.MyWorker;
/*
 * 
 * 
 * sddsd
 * 
 */

public class ThreadManger {
	
	
	    private class Spyer  extends Thread{
		private  boolean ISEND = false;
		private volatile boolean flag=false;
		private Object control= new Object();
		
		private volatile  boolean _susspend =false;
   
		
		//private boolean Wwakeup =false;
		//private boolean  end = false;

		
		public void run(){
			
			while(!ISEND) {
				synchronized (control) {
					if(_susspend) {
						try {
							control.wait();//�ؼ�  ���߳�wait���ͷ���
						}catch (InterruptedException e) {
							//e.printStackTrace();		
							break;
						}		
					}		
				}
				
				try {
					Thread.sleep(8000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					break;
				}
			
				if(folders.isEmpty()&&!flag) {
					if(task!=null&&task.isEmpty()) {
						for(Thread e : pool )  {	
							if(e instanceof MyWorker) 
								((MyWorker) e).setEnd(true);
						}
					}
					
					
					
					for(Thread e:pool) {
						if(e instanceof FuSearchFileThread) ((FuSearchFileThread)e).setEnd(true);
						else if(e instanceof AbSearchFileThread)((AbSearchFileThread)e).setEnd(true);
						flag=true;
					}
					
					try {
						Thread.sleep(50);
					} catch (InterruptedException e1) {}
					
					
					SwingUtilities.invokeLater(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							JOptionPane.showMessageDialog(null,"�����߳��Ѿ�����,������н����ȴ����20������(�ڼ䲻�ܲ���)!!!\n\n\t\t\t\t\t\t\t\t���������","��Ϣ",JOptionPane.PLAIN_MESSAGE);
						}
					});
					
					try {
						Thread.sleep(50);
					} catch (InterruptedException e1) {}
					
					transferThread.setSleeptime(0);
					
				}
				
				else if(result.size()>=10000) //�ӿ��ȡ�ٶ�   Ϊԭ���� 5��
				{
					
					transferThread.setSleeptime(500);
				//	System.out.println("�ٶȼӿ�Ϊԭ���� 4��");
				}
				
			}
				
			SwingUtilities.invokeLater(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					JOptionPane.showMessageDialog(null,"Spyer����","��Ϣ",JOptionPane.PLAIN_MESSAGE);
				}
			});
		
				
		}
		
		public void setSuspend (boolean suspend) {
			if(!suspend) {
				synchronized (control) {
					control.notify();	
				}
			}
			this._susspend=suspend;
		}

		public void  setEnd(boolean end) {
			if(spyer.isAlive()) {
				this.ISEND=end;
				this.interrupt();
			}
		
		}
	}
	
	
	
private  ArrayList<Thread> pool;
	
	private volatile    int Poolsize=0;
    // private static int capacity=0;

private    Vector<FileData> result;


private   Transfer transferThread ;
private  Vector <File>folders;
private   Spyer spyer;
private BlockingQueue<Runnable> task  =null;

public void SpyResult(Vector<FileData> result) {
	this.result =result;
}




public ThreadManger() {
   pool  =new ArrayList<Thread>();
   // this.capacity = Integer.MAX_VALUE;
}




public void StartSpyer() {
	
	if(transferThread.isAlive()) {
		spyer= new Spyer();
		spyer.start();
	}

}


//

//
//
//public void  SusspendSpyer(boolean f) {
//	spyer.setSuspend(f);
//}


//
//	public ThreadManger(int capacity) {
//      pool  =new ArrayList<Thread>(capacity);
//	 //  this.capacity = capacity;
//	}
	
	
	public void SPyFolder(Vector<File>  folders) {
		this.folders=folders;
	}
	
	
	public void mexecute(Thread  t) {

		if(t instanceof Transfer)  transferThread =(Transfer)t;
		else pool.add(t);
	
		//�ύ�߳�  ������
		
	     t.start();
	     //System.out.println(t.getName() +" ��ʼ����");
	     Poolsize ++;
	}
	
	public void setSusspend(boolean susspend) {
		for(Thread e : pool) {
			//System.out.println("��ͣ��ʼ");
			if(e instanceof  FuSearchFileThread ) ((FuSearchFileThread)e).setSuspend(susspend);
			else if  (e instanceof  AbSearchFileThread)((AbSearchFileThread)e).setSuspend(susspend);
			else if( e instanceof MyWorker) ((MyWorker)e).setSuspend(susspend);
		}
		
		transferThread.setSusspend(susspend);
		//spyer.setSuspend(susspend);
	}
	
	
	
	public void mInterrupt() {
		//System.out.println("end1");
		for(Thread e : pool) {
			
			if(e instanceof FuSearchFileThread) ((FuSearchFileThread)e).setEnd(true);
			else if(e instanceof AbSearchFileThread) ((AbSearchFileThread)e) .setEnd(true);
			else if(e instanceof MyWorker) ((MyWorker)e).setEnd(true);
		}
		
		// transferThread.setSleeptime(0);
		transferThread.setEnd(true);
		//transfer�߳�һ����  ��Ҫ��������  ����  ����  ȫ��һ�������Ľ��  ����UI  list����
		if(!result.isEmpty())result.clear();
       
		if(spyer!=null)spyer.setEnd(true);
		
		try {
			Thread.sleep(50);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
	}
	
	public boolean mIsAlive() {
//		for(int i=0;i<size;i++) {	
//			System.out.println(pool.get(i)+"     " +pool.get(i).isAlive());
//		}
		if(Poolsize==0) return false;
	   for(Thread e: pool) if(e.isAlive()) return true;
	
	return false;
	}
	
	
	
	public boolean TFisAlive() {
		if(mIsAlive()) return true;
		else if(result.isEmpty()) {//�����̹߳ر�  �������ȫ�� ����UI list  ����������߳�
			//��� �����߳��ڴ˹ر�
			//System.out.println("bisend");
			if(spyer!=null)spyer.setEnd(true);
			
			transferThread.setEnd(true);
			//transferThread.interrupt();
			
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//if(transferThread.isAlive()) System.out.println("�����߳��˳��쳣");
			//if(spyer.isAlive())System.out.println("Spyer�˳��쳣");
			
			//while(transferThread.is)
			return false;
		}
		else return true;
	}
	
	public void Clear() {
		pool.clear();
		transferThread=null;
		spyer=null;
		System.gc();
	}




	public void SpyTask(BlockingQueue<Runnable> task) {
		// TODO Auto-generated method stub
		this.task= task;
	}
	
	
//	public  void Start() {
//		System.out.println(size);
//		for( Thread e: pool)
//		{
//			System.out.println(e);
//			e.start();
//			try {
//				Thread.sleep(200);
//			} catch (InterruptedException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//		}
//		
//	}
	
	
}
