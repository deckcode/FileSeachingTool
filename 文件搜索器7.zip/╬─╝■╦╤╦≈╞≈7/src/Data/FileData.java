package Data;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileData {

	//private static SimpleDateFormat dateformat = new SimpleDateFormat("yyyy��  MM�� dd��");	  
	private  String  FileName;
	/**
	 * @return the dateformat
	 */
//	public static SimpleDateFormat getDateformat() {
//		return dateformat;
//	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return FileName;
	}

	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return FileType;
	}

	/**
	 * @return the fileSize_kbyte
	 */
	public String getFileSize_kbyte() {
		return FileSize_kbyte;
	}

	/**
	 * @return the modifyDate
	 */
	public String getModifyDate() {
		return ModifyDate;
	}

	/**
	 * @return the author
	 */
	public String getAuthor() {
		return Author;
	}

	/**
	 * @return the pathName
	 */
	public String getPathName() {
		return PathName;
	}

	public File  getFile() {
		return file;
	}

	private  String FileType;
	private String  FileSize_kbyte;
	private String ModifyDate;
	private String Author;
	private String PathName;
	private  File   file;
	private String IsHidden;
   private   Pattern pattern;
	private boolean   IsFile;
	
	private String FileID;//�ļ����
	/**
	 * @return the fileName
	 */
	
	//����ƥ��  �������
  	public FileData(File file,Pattern pattern) {
		//��ǰ����������Ⱦ
		this.file= file;
		String name = file.getName();
		FileType ="<HTML><font color='orange' size='4'> �� �� :  </font>"+(file.isFile()?getFileType(name):"null");
		FileName ="<HTML><font size = '5' color='orange'> �� �� : </font>"+RegexMatches(pattern,name);
       PathName = "<HTML><font size = '5' color='orange' > · �� �� : </font>"+file.getPath();
       FileSize_kbyte="<HTML><font color='orange' size='4'> �� С :  </font> "+file.length()+"KB";
       IsHidden =  "<HTML><font color='orange' size='4'> Hidden :  </font> "+(file.isHidden()?"��":"��");
       IsFile = file.isFile();
     
      // ModifyDate="<HTML><font color='orange' size='4'> �� �� �� �� : </font> "+dateformat.format(new Date(file.lastModified()));
	}

  	private  String RegexMatches(Pattern pattern2,String chs ) {
  		pattern=	Pattern.compile(pattern2.toString().replaceAll("[\\*\\\\.]", ""));

  		Matcher mat=pattern.matcher(chs.toLowerCase());
  		StringBuilder  result=new StringBuilder(); 
  		if(mat.find()) {
  			int index1 = mat.start();
  			int index2 = mat.end();
  			
  	           result.append("<font size='4'>"+chs.substring(0,index1)+"</font>"+"<font size='4'  color='red'>"+chs.substring(index1,index2)
  	           +"</font>"+"<font size='4'>"+chs.substring(index2,chs.length())+"</font>");
		return result.toString();
  		
     	}
  		else {
  			result.append("<font size='4'>"+chs+"</font>");
  			return result.toString();
  		}
  }
  	
  	//����ƥ��  �������
	public FileData(File file) {
		//��ǰ����������Ⱦ
		this.file= file;
		String name = file.getName();
		FileType ="<HTML><font color='orange' size='4'> �� �� :  </font>"+getFileType(name);
		FileName ="<HTML><font size = '5' color='orange'> �� �� : </font>"+name;
       PathName = "<HTML><font size = '5' color='orange' > · �� �� : </font>"+file.getAbsolutePath();
       FileSize_kbyte="<HTML><font color='orange' size='4'> �� С :  </font> "+file.length()+"KB";
       IsHidden =  "<HTML><font color='orange' size='4'> Hidden :  </font> "+(file.isHidden()?"��":"��");
       IsFile = file.isFile();
     
      // ModifyDate="<HTML><font color='orange' size='4'> �� �� �� �� : </font> "+dateformat.format(new Date(file.lastModified()));
	}
	
public void setFilID(int id) {
	FileID=""+id;
}
	private static  String getFileType(String e) {
		//	System.out.println(e.getName());
				//�ļ������ܺ��ж��  �� . �� 
			int index =e.lastIndexOf(".");
			//System.out.println(index);
		      if(index>=0) 	 {
		    	//System.out.println(e.getName().substring(index));
		    	return e.substring(index+1);
		    }
		    else return "null";
		      
		      
			}
	
	
//	private String Matches(String keychar,String str) {
//		StringBuilder  result=new StringBuilder(); 
//		int index1=str.toLowerCase().indexOf(keychar);
//		int keycharlength =keychar.length();
//		int strlength =  str.length(); 
//		if(index1==-1) result.append("<font size= '4'> "+str+ "</font>");
//		else {
//			//����
//			//System.out.println(index1);
//			
//			if(index1==0) result.append("<font color = 'red' size ='4'>"+str.substring(0,keycharlength)+"</font><font size= '4'>"+str.substring(keycharlength)+"</font>");
//			//��β
//			else if(index1==strlength-keycharlength) result.append("<font size= '4'>"+str.substring(0,index1)+"</font><font color = 'red' size ='4'>"+str.substring(index1)+"</font>");
//			//����
//			else {
//				
////				System.out.println(str.substring(0,index1));   
////				System.out.println(str.substring(index1+keychar.length()-1,str.length()-1));
//				result.append("<font size='4'>"+str.substring(0,index1)+"</font><font  size ='4'  color = 'red'>"+str.substring(index1,index1+keycharlength)+"</font><font size ='4'>"+str.substring(index1+keycharlength)+"</font>"); 
//			}
//		}

//		
//		return result.toString();
//		
//	}

	public String getIsHidden() {
		return IsHidden;
	}

	public boolean isIsFile() {
		return IsFile;
	}


	public String getFileID() {
		return FileID;
	}
	
}
