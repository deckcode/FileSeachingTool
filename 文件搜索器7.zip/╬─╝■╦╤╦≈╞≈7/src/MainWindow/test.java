package MainWindow;

import java.io.File;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	System.out.println("jnnjjnj");
		//System.out.println("fodfgkk/\\\\".replaceAll("[\\/]", File.pathSeparator));
		new MainFrame();
	}

}
