package MainWindow;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.awt.geom.RoundRectangle2D;
import java.awt.image.ImageObserver;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Vector;
import java.util.regex.Pattern;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.WindowConstants;
import javax.swing.border.Border;

import AbsoluteSearch.abMainThread;
import Data.FileData;
import EncodeDetector.Ecoding2;
import FuzzySearch.fuMainThread;
import SearchMode.RegexSearch;
import ViceWindow.ViceFrame;



public class MainFrame extends JFrame   implements ActionListener{

	/**
	 * 
	 */
	private  ViceFrame viceframe =null;
	private volatile Vector<FileData> result =new Vector<FileData>();
	private static final long serialVersionUID = 6408103300821524068L;
	
	
	//���ñ�־λ
	private volatile boolean ISEND=true;
	
	public void setEnd() {
		ISEND =true;
		Susspended =false;
	}
	private volatile boolean  Susspended= false;
	
	
	
	private  Thread  SearchThread =null;

	private static	 Border Compound ;
	private static  JLabel ExitIcon;
	private static JLabel  NarrowIcon;
	private static JLabel ExitIcon_Clicked;
	private static JLabel  NarrowIcon_Clicked;
	private static Border BtnBorder;
private static Color BtnColro;

private static Font txtfont;
    private JLabel Title2;
	private JLabel  Title ;
	private JPanel  pane ;
	private JButton NarrowBtn;
	private static ImageIcon TIcon;
	private JButton ExitBtn;
	
	private  JLabel  DragBar;
	
	private JLabel pathlabel ;
	private JLabel filelabel;
	private JTextField pathText;
	private JTextField fileText ; 
	/*
	 *  @����ģʽ
	 */
	private JLabel searchmode ;
    private JRadioButton mode1Btn ;
     private JRadioButton mode2Btn ;
     

     /*
      *@ �Ƿ������ı�����
      */
     private JLabel searchtext ;
     private JRadioButton trueBtnl;
     private JRadioButton falseBtn;
     
     private JButton confBtn;
     private JButton stpBtn ;
     private JButton cansBtn ;
     

	  private static  Font textFont; 
	  
	  private ButtonGroup  modegrp;
	  private ButtonGroup  searchgrp;
	   
	  private JRadioButton trueBtn ;
		private static Pattern  pattern2;
		private static Pattern pattern1;
	  
		
		private static File[] Roots;
		
		private static   TreeSet<String>Searchrecord ; 
		
		private static TreeSet<String> Pathrecord;
		
		
	static {
	
		Searchrecord =new TreeSet<String>();
		Pathrecord =new   TreeSet<String>();
		
		
try(InputStreamReader   of = new InputStreamReader(new FileInputStream(new File("src/SearchRecord")), Ecoding2.getFilecharset(new File("src/SearchRecord")))){
			
			BufferedReader reader =new BufferedReader(of);
			
			String temp;
			
		while((temp=reader.readLine())!=null) {	
			Searchrecord.add(temp);
			//System.out.println(temp);
			//System.out.println(Searchrecord.contains(temp));
		}
			
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


try(InputStreamReader   od = new InputStreamReader(new FileInputStream(new File("src/PathRecord")), Ecoding2.getFilecharset(new File("src/PathRecord")))){
	
	BufferedReader reader =new BufferedReader(od);
	
	String temp;
	
while((temp=reader.readLine())!=null) {	

	Pathrecord.add(temp);
	//System.out.println(temp);
}
	
	
} catch (UnsupportedEncodingException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


		
		txtfont  = new Font("΢���ź�",Font.BOLD,20);
		TIcon=new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/imgs/edit_find.png").getScaledInstance(25, 30,Image.SCALE_SMOOTH));
		BtnColro   = new Color(214,217,223);
		//���ϱ߿�  �����ڲ�  �ⲿ�߿�
		Compound = BorderFactory.createCompoundBorder(
					BorderFactory.createLineBorder(Color.gray, 3, true), 
					BorderFactory.createLoweredBevelBorder());
		//ͼƬ̫С���ز���
		BtnBorder = BorderFactory.createSoftBevelBorder(ERROR, Color.blue, Color.gray);
//		NarrowIcon.setIcon(new ImageIcon((Toolkit.getDefaultToolkit().getImage("src/imgs/Narrow.PNG")).getScaledInstance(40, 20, Image.SCALE_SMOOTH)));
//		NarrowIcon_Clicked.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/imgs/NarrowClicked.png").getScaledInstance(40, 20, Image.SCALE_SMOOTH)));
//		ExitIcon.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/imgs/Exit.PNG").getScaledInstance(40, 20, Image.SCALE_SMOOTH)));
//		ExitIcon_Clicked.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage("src/imgs/ExitClicked.png").getScaledInstance(40, 20, Image.SCALE_SMOOTH)));
//		
		
		Roots = File.listRoots();
		
		textFont =new Font("����",Font.BOLD,20);
		pattern2 =Pattern.compile("[/\\:\"<>]");
		pattern1= Pattern.compile("[\"<>?*]");
		
	}
	
	
	
	public MainFrame() {
		

		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	SwingUtilities.updateComponentTreeUI(this);
	
//	Image   im =Toolkit.getDefaultToolkit().getImage("src/imgs/��С.PNG");
//	Image im2 = im.getScaledInstance(40, 20, Image.SCALE_SMOOTH);
//	
//	ImageIcon img =new ImageIcon("src/imgs/ExitClicked.png");
//	//ico���ز���ͼƬ �ĳ�png
//	Image im3 = Toolkit.getDefaultToolkit().getImage("src/imgs/Narrow.PNG");

	Title2 =  new  JLabel("<html><font size ='��һ' color = 'purple'>��  ��  ��  ��</font>");
	Font font = new Font("����",Font.BOLD,60);
	Title2.setFont(font);
	Title2.setForeground(Color.white);
	
	 pathlabel =new JLabel("ָ��·��");
	 filelabel= new JLabel("�����ļ�");
	DragBar = new JLabel();
	
	 
	 pathText= new JTextField();
	 fileText = new JTextField(); 
	
	
	Title = new JLabel();	
	NarrowBtn = new JButton("��");
	ExitBtn = new JButton("x");
	pane = new JPanel();

	 modegrp = new ButtonGroup();
	 searchgrp = new ButtonGroup();
    
	  /*
      * ����ģʽ
      */
	 
     searchmode = new JLabel("����ģʽ");
   
     
     mode1Btn= new JRadioButton("��������",false);

     mode2Btn= new JRadioButton("ģ������",true);
     
     
     modegrp.add(mode1Btn);
     modegrp.add(mode2Btn);
	


    
     searchtext =new JLabel("�����ļ�����");
     trueBtn =new JRadioButton("��",false);
      falseBtn =new JRadioButton("��",true);
      searchgrp.add(falseBtn);
      searchgrp.add(trueBtn);
      
      
      confBtn =new JButton("����");
      stpBtn = new JButton();
      stpBtn.setText("��ͣ");
      cansBtn = new JButton("");
      cansBtn.setText("ȡ��");
     
//    DESK = FileSystemView.getFileSystemView().getHomeDirectory().toPath();
//     System.out.println(DESK);
      
    
	setFrame();
	addComponent();
	addListener();
	}
	
	private void setFrame() {
		DragBar.setFocusable(true);
		DragBar.setBounds(0,0,810,30);
		Title.setBounds(15,1,120,30);
		Title.setText("�� �� �� �� �� �� ");
         Title.setIcon(TIcon);
		Title.setForeground(Color.cyan);
		
		Title2.setBounds(230,40,600,80);
		
		NarrowBtn.setForeground(Color.blue);
		ExitBtn.setForeground(Color.red);
		ExitBtn.setBorder(BtnBorder);
		NarrowBtn.setBorder(BtnBorder);
		ExitBtn.setBounds(758,0,40,20);
		NarrowBtn.setBounds(716,0,40,20);
		
		pathlabel.setBounds(20,20,100,40);
		pathlabel.setFont(textFont);
		pathlabel.setForeground(Color.pink);
		pathText.setBounds(120,20,540,40);
		pathText.setFont(txtfont);
		pathText.setText(Roots[0].toString());
		pathText.setForeground(Color.pink);
		
		
		filelabel.setBounds(20,100,150,40);
		filelabel.setFont(textFont);
		filelabel.setForeground(Color.pink);
		fileText.setBounds(120,100,540,40);
		fileText.setFont(txtfont);
		fileText.setForeground(Color.pink);
		
		
		searchmode.setBounds(20,180,150,40);
		searchmode.setFont(textFont);
		searchmode.setForeground(Color.pink);
		
		mode1Btn.setBounds(220,180,150,40);
		mode1Btn.setFont(textFont);
		mode1Btn.setForeground(Color.pink);
		
		mode2Btn.setBounds(500,180,150,40);
		mode2Btn.setFont(textFont);
		mode2Btn.setForeground(Color.pink);
		
		searchtext.setBounds(20,250,150,40);
		searchtext.setFont(textFont);
		searchtext.setForeground(Color.pink);
		
		  trueBtn.setBounds(220,250,150,40);
		  trueBtn.setFont(textFont);
		  trueBtn.setForeground(Color.pink);
		  
		  falseBtn.setBounds(500,250,150,40);
		  falseBtn.setFont(textFont);
		  falseBtn.setForeground(Color.pink);
		
		  confBtn.setBounds(50,300,100,50);
		  confBtn.setFont(textFont);
		  confBtn.setForeground(Color.blue);
		  
		  stpBtn.setBounds(300,300,100,50);
		  stpBtn.setFont(textFont);
		  stpBtn.setForeground(Color.blue);
		  
		  cansBtn.setBounds(530,300,100,50);
		  cansBtn.setFont(textFont);
		  cansBtn.setForeground(Color.blue);
		  
       //System.out.println( Narrow.getBackground());
		
		pane.setBounds(50,150,700,400);
		//pane.setOpaque(true);
	
	    pane.setBorder(BorderFactory.createLineBorder(new Color(51,90,117),10,true));
		pane.setBackground(new Color(51,90,117));
		
		//  ����setUndecorated(true);  �� this.setOpacity(0.6f);����Ч  ��Ĭ���������������������� Ϊ ͸��  ��  setOpaque Ϊ false Ҫ������ʾ �� true
	   setUndecorated(true);
        this.setOpacity(0.8f);
		this.setLayout(null);
		setSize(800, 600);
		setLocationRelativeTo(null);
	//	this.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG );
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setTitle("�ļ���������");
		setIconImage(Toolkit.getDefaultToolkit().getImage("src/imgs/edit_find.png"));
		//���ô���  �����ǵľ���
		/*
		 * 	������
											 Բ�ǵ�Բ���ĸ߶ȡ�
											double	arcwidth	
											Բ�ǵ�Բ�����ȡ�
											double	height	
											����ĸ߶�RoundRectangle2D��
											double	width	
											�Ŀ���RoundRectangle2D��
											double	x	
											�˵�X����RoundRectangle2D��
											double	y	
											�˵�Y����RoundRectangle2D��
		 */
		this.setShape(new RoundRectangle2D.Double(0d,0d,getWidth(),getHeight(),40,40));
	}

	private void addComponent() {
		this.setEnabled(true);
		pane.add(searchmode);
		pane.add(mode2Btn);
		pane.add(mode1Btn);
		
		pane.add(stpBtn);
		pane.add(cansBtn);
		pane.add(confBtn);
		
		
		pane.add(searchtext);
		pane.add(trueBtn);
		pane.add(falseBtn);
		
		pane.add(pathlabel);
		pane.add(pathText);
		pane.add(filelabel);
		pane.add(fileText);
		
		pane.setLayout(null);


	
		Container floorpanel = this.getContentPane();

		floorpanel.setBackground(Color.lightGray);;
		floorpanel.add(ExitBtn);
		floorpanel.add(NarrowBtn);
		floorpanel.setFocusable(true);
		floorpanel.setEnabled(true);
		floorpanel.add(Title);
		floorpanel.add(Title2);
		floorpanel.add(DragBar);
	   floorpanel.add(pane);
	
	   pane.setOpaque(true);

	}

	private void addListener()
	{
		//��¼���λ��   ʵ����ק
		_addListener(DragBar);
		_addListener(NarrowBtn);
		_addListener(ExitBtn);
		
		
		_addListener(confBtn);
		_addListener(cansBtn);
		_addListener(stpBtn);
		
		//����  ���  �����������
		pathText.addMouseListener(new MouseAdapter() {
			
			@Override
			public  void mouseClicked(MouseEvent e) {
				if(e.getClickCount()>=2) {
		        	
	        		 JPopupMenu popupmenu = new JPopupMenu();
	        		 popupmenu.setPopupSize(540, Pathrecord.size()*30);
	    			 //�����˵���   ---  �̷�& ���� ·��
	        		 Iterator<String>  it=Pathrecord.iterator();
	        		 
	        		 while(it.hasNext()) {
	        			 JMenuItem item= new  JMenuItem(""+it.next());
	        			// item.setSize(540, 20);
	    				 item.addActionListener(new ActionListener() {
	    					
	    					@Override
	    					public void actionPerformed(ActionEvent e) {
	    						// TODO Auto-generated method stub
	    						//System.out.println(e.getActionCommand());
	    					pathText.setText(e.getActionCommand());
	    					}
	    				});
	    				 popupmenu.add(item);
	        		 }
	    	           popupmenu.setBorder(BorderFactory.createLineBorder(Color.cyan,2,true));
	    	        	popupmenu.show(e.getComponent(), 0, 40);

	        	}
			
			}
		});
		
		
		
		//fileText.addMouseListener(new Btn_JTXMouseMotionListener(this, fileText ,Searchrecord));
		fileText.addMouseListener(new MouseAdapter() {
			@Override
			public  void mouseClicked(MouseEvent e) {
				if(e.getClickCount()>=2) {
		        	
				//	System.out.println("yes");
	        		 JPopupMenu popupmenu = new JPopupMenu();
	        		 popupmenu.setPopupSize(540, Searchrecord.size()*30);
	    		
	        		 Iterator<String>  it=Searchrecord.iterator();
	        		// System.out.println(it.next());
	        		 while(it.hasNext()) {
	        			
	        			 JMenuItem item= new  JMenuItem(""+it.next());
	        			// item.setSize(540, 20);
	    				 item.addActionListener(new ActionListener() {
	    					
	    					@Override
	    					public void actionPerformed(ActionEvent e) {
	    						// TODO Auto-generated method stub
	    						//System.out.println(e.getActionCommand());
	    							fileText.setText(e.getActionCommand());
	    					}
	    				});
	    				 popupmenu.add(item);
	        		 }
	    	           popupmenu.setBorder(BorderFactory.createLineBorder(Color.cyan,2,true));
	    	        popupmenu.show(e.getComponent(), 0, 40);

	        	}
			
			}

		});
		
		
		
		
		
		
		confBtn.addActionListener(this);
		cansBtn.addActionListener(this);
		stpBtn.addActionListener(this);
	
		//��������Ƿ�����
		pathText.addKeyListener(new KeyAdapter() {				
		@Override
		public void keyTyped(KeyEvent e) 
		 {
				char ch = e.getKeyChar();
				//pattern1.matcher(String.valueOf(ch)).matches()
			
			if(String.valueOf(ch).matches("[?*\"<>|]"))
			{
				e.consume();
				JOptionPane.showMessageDialog(null,"\t\t·����������   ? * \" < > | ��Ӣ���ַ���");
			}

		}
		});
		//��������Ƿ�����
		fileText.addKeyListener(
				
				new KeyAdapter() //�ı������� ���̼�����  ��������������  ��дkeypressed
		{
			
//		public void keyPressed(KeyEvent e) {
//			char ch = e.getKeyChar();
//			if(String.valueOf(ch).matches("[\\/:\"<>|]")) {
//				e.consume();
//				JOptionPane.showMessageDialog(null,"\t\t\t�������!!!\n��Ҫ���� \\ / :  < > | ��Ӣ���ַ���");
//			}
//			
//		}
			@Override
			public void keyTyped(KeyEvent e) 
			{
				char ch = e.getKeyChar();
				
			
			   
				if( String.valueOf(ch).matches("[/\\:\"<>|]"))
				{
				e.consume();
//			    JDialog  input_error_dialog=new JDialog(frame,"������󣡣���",true); //ģ̬�Ի���
//			    input_error_dialog.setBounds(scrSize.width/2-260,scrSize.height/2-170,360,100);
//			    input_error_dialog.getContentPane().setLayout(new BorderLayout());

//			    input_error_dialog.getContentPane().add("North",new JLabel("                     �ļ��������������κ��ַ�(Ӣ��):"));
//			    input_error_dialog.getContentPane().add("Center",new JLabel("                              \\ / : * ? < > |"));
//			    input_error_dialog.setVisible(true);
				//����ϵͳ�Դ��� ��Ϣ��
				JOptionPane.showMessageDialog(null,"\t\t\t�������!!!\n��Ҫ���� \\ / :  < > | ��Ӣ���ַ���");
			    
				}
			}
		}    );
		
	}
	
	private void _addListener(Component a) {
		Btn_JTXMouseMotionListener  listener=new Btn_JTXMouseMotionListener(this);
		a.addMouseListener(listener);//addMouseListener ����Ӧ ��ק�¼�
		a.addMouseMotionListener(listener);//addMouseMotionListener  ����Ӧpressed�¼�
	}

	
	//��ӦconfBtn  cansBtn   stpBtn  ��ť����¼�  ��ҪΪ�����׻�ȡ���������������������
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

			if(e.getSource()==confBtn) {
			//	System.out.println("����");
				//System.out.println(e.toString());
				String RootPath ="";
				String searchChar ="";
				RootPath = pathText.getText();
				searchChar	=fileText.getText();
				
				//System.out.println(RootPath);
				//System.out.println("Fgfgfg");
				//System.out.println(RootPath +  searchChar);
				//if(searchChar==null)
				//��������ڵ�  ���ݼ�¼���������ļ�
				if(!searchChar.equals("")&&!RootPath.equals("")) {
					
					//System.out.println("heere");
					
					if(Searchrecord.add(searchChar)) {
						
						if(Searchrecord.size()>=12) Searchrecord.remove(Searchrecord.higher(searchChar));
						try(OutputStreamWriter   od = new OutputStreamWriter(new FileOutputStream(new File("src/SearchRecord"),false), Ecoding2.getFilecharset(new File("src/SearchRecord")))){
							Iterator<String>	 it = Searchrecord.iterator();
							while(it.hasNext()) {
								od.write(it.next()+"\n");
							}
							
							} catch (UnsupportedEncodingException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
					}
					
					
				
					
					if(Pathrecord.add(RootPath))
					{
						if(Pathrecord.size()>=12) Pathrecord.remove(Pathrecord.higher(RootPath));
						try(OutputStreamWriter   of = new OutputStreamWriter(new FileOutputStream(new File("src/PathRecord"),false), Ecoding2.getFilecharset(new File("src/PathRecord")))){
						Iterator<String>	 it = Pathrecord.iterator();
						while(it.hasNext()) {
							of.write(it.next()+"\n");
						}
						
							} catch (UnsupportedEncodingException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
					}
	
				}
				
				else {
					JOptionPane.showMessageDialog(null,"�루��������·�����ڣ������ѯ����","�����쳣",JOptionPane.ERROR_MESSAGE);
					return ;
				}
				
				
				//JRadioButton   ���취  һ�����ж��Ƿ�ѡ��
				String SearchMode =null;
				String isSearchFileInner  =null;
				 Enumeration<AbstractButton> radioBtns=modegrp.getElements();
				 
					while(radioBtns.hasMoreElements()) 
					{
						AbstractButton btn = radioBtns.nextElement();
						if(btn.isSelected()) {
							SearchMode=btn.getText();
							break;
						}
					}
						
						
						 Enumeration<AbstractButton> radioBtns2=searchgrp.getElements();
						 while(radioBtns2.hasMoreElements()) {
							 AbstractButton btn =  radioBtns2.nextElement();
							 	if(btn.isSelected()) {
							 		isSearchFileInner = btn.getText();//Gets the name of the component.
							 		break;
							 	}
					}
						// ViceFrame2 viceframe2=ViceFrame2.getSinglinstance();
						
						if(ISEND) {
						   //System.out.println("dfkgk");
							File Root = new File(RootPath);
							
							if(Root.exists()) {
								// System.out.println("·����  : "+RootPath+ " ������  "+searchChar +"  ģʽ  "+SearchMode +" �Ƿ�����ļ�����  "+isSearchFileInner);

								  viceframe= ViceFrame.getSinglinstance();
								  //��ʼ�µ�����     ԭ����������
							      viceframe.clear();
					    	      result.clear();
					    	      
					    	      
		                          if(viceframe!=null) {
		                        	  
		                        	  Pattern pattern =null;
		                        	  
		                        	  if(SearchMode.equals("ģ������")) {
		   
		                        		   	 pattern= Pattern.compile(RegexSearch.getRegexChar(searchChar));
				  	  							//System.out.println(pattern);
				  	  							//System.out.println(pattern.matcher("ewfwfdf.df").find());
				  	  						SearchThread =new fuMainThread(this,result,Root,pattern,(isSearchFileInner.equals("��")?true:false),viceframe);
		  	  						   }
		                        	   else {
		                        		   if(isSearchFileInner.equals("��")) JOptionPane.showMessageDialog(null,"�����������ܽ����ļ���������","��Ϣ",JOptionPane.PLAIN_MESSAGE); 
		                        		   else  SearchThread=new abMainThread(this,result,Root, searchChar.toLowerCase(), viceframe,(isSearchFileInner.equals("��")?true:false));
		                        	   }
		                        	   
		                        	   
		                        	   	if(SearchThread!=null)
			    					    	{    //�������̿�ʼ
		                        	   		       SearchThread.start(); 
		                        	   		       //�������� ��ʱ������
													viceframe.CounterStart(RootPath,(pattern==null?searchChar:pattern.toString()),SearchMode,isSearchFileInner);
		                        	   		     ISEND=false;
			    					    	}
		                          }
		                          else JOptionPane.showMessageDialog(null,"�������ڴ��쳣","�쳣",JOptionPane.ERROR_MESSAGE);
						}
							
							  else JOptionPane.showMessageDialog(null,"����·��������","�쳣",JOptionPane.ERROR_MESSAGE);
						}
						else JOptionPane.showMessageDialog(null, "��������","��Ϣ",JOptionPane.ERROR_MESSAGE);
											
                          //Thread  serachThread  = new Thread(new MainSearch5(e, root, keychar, IsSearchFileInner, frame))
			}
			
			else if(e.getSource()==cansBtn) {
			    //System.out.println("ȡ��");
			    if(ISEND) {
			    	JOptionPane.showMessageDialog(null,"�����쳣","�쳣",JOptionPane.ERROR_MESSAGE);
			    }
			    
			    else {	
			    	//cansBtn.updateUI();
			    	if(SearchThread!=null) {
					    //���߳� ��ֹ
			    		cansBtn.setText("��ȴ�");
			    		
			    		stpBtn.setEnabled(false);
			    		stpBtn.setFocusable(false);
			    		cansBtn.setFocusable(false);
			    		cansBtn.setEnabled(false);
			    		confBtn.setEnabled(false);
			    		confBtn.setFocusable(false);
			    		
			    		
			    		//cansBtn.updateUI();
			    		// viceframe.CloseCounter();
			    		 
			    		 JOptionPane.showMessageDialog(null,"������ǰ������ȴ����10�����ң�����\n\n�����������","��Ϣ",JOptionPane.INFORMATION_MESSAGE);
			    		 
			    		 
				    	if(SearchThread instanceof fuMainThread )  {
				    	   ((fuMainThread) SearchThread).setStop();
				    	 
				    	}
				    	else {
				    		((abMainThread) SearchThread).setStop(); 
				    	}
				    	//�ȴ����й����Ѿ�����  �Ž�����һ������
								 while(SearchThread.isAlive());
								 
								    SearchThread =null;
									cansBtn.setText("ȡ��");
									stpBtn.setText("��ͣ");
									System.gc();

									stpBtn.setEnabled(true);
						    		stpBtn.setFocusable(true);
						    		cansBtn.setFocusable(true);
						    		cansBtn.setEnabled(true);
						    		confBtn.setEnabled(true);
						    		confBtn.setFocusable(true);
						    		Susspended=false;
						    		
								if(JOptionPane.showConfirmDialog(null, "�Ƿ���һ��������ʼ", "��Ϣ", JOptionPane.OK_CANCEL_OPTION)==JOptionPane.CANCEL_OPTION) {
								    System.exit(0);
								}
								//System.out.println(ISEND);
									//cansBtn.updateUI();
				    }

					
			    }
			    
				 
			}
			
			else if(e.getSource()==stpBtn) {
				// System.out.println("��ͣ");
				 if(ISEND) {
					 JOptionPane.showMessageDialog(null,"�����쳣","�쳣",JOptionPane.ERROR_MESSAGE);
				 }
				 
				 else {
					 //System.out.println("����");
					 if(viceframe!=null) {
							try {
		                        Thread.sleep(200);
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null,"�������д��󣡣���","�쳣",JOptionPane.ERROR_MESSAGE);
						}
							if(!Susspended) {
							//	System.out.println("����");
								
								
								stpBtn.setFocusable(false);
								stpBtn.setEnabled(false);
					    		cansBtn.setEnabled(false);
					    		cansBtn.setFocusable(false);
					    		confBtn.setEnabled(false);
					    		confBtn.setFocusable(false);
					    		
					    		
								if(SearchThread instanceof fuMainThread )   ((fuMainThread)SearchThread).setSusspend(true);
								else	if(SearchThread  instanceof  abMainThread){
									//System.out.println("����"); 
									((abMainThread)SearchThread).setSusspend(true);
								}
								viceframe.SusspendCounter();
								stpBtn.setText("����");
								
								try {
									Thread.sleep(2000);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								stpBtn.setFocusable(true);
								stpBtn.setEnabled(true);
					    		cansBtn.setEnabled(true);
					    		cansBtn.setFocusable(true);
					    		confBtn.setEnabled(true);
					    		confBtn.setFocusable(true);
			
								Susspended=true;
							}
							
							else if(Susspended) {
								//System.out.println("����");
								//��ͣ�������в�����  ��Ӧ
								stpBtn.setFocusable(false);
								stpBtn.setEnabled(false);
					    		cansBtn.setEnabled(false);
					    		cansBtn.setFocusable(false);
					    		confBtn.setEnabled(false);
					    		confBtn.setFocusable(false);
					    		
					    		
								if(SearchThread instanceof fuMainThread )   ((fuMainThread)SearchThread).setSusspend(false);
								else ((abMainThread)SearchThread).setSusspend(false);
								viceframe.notifyCounter();
								stpBtn.setText("��ͣ");
								
								try {
									Thread.sleep(2000);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								stpBtn.setFocusable(true);
								stpBtn.setEnabled(true);
					    		cansBtn.setEnabled(true);
					    		cansBtn.setFocusable(true);
					    		confBtn.setEnabled(true);
					    		confBtn.setFocusable(true);
								Susspended=false;
							}
						}
					 
				 }
				
					
				 
		}
			

		
	}
	
}

class  Btn_JTXMouseMotionListener extends  MouseAdapter{
	private static Color BtnColro;
	//oldpointһ��Ҫ����Ϊ  static��  addMouseListener ��pressed��Ӧ����  addMouseMotionListener   Draged��Ӧ����   ����һ��  oldpoint
	//����  static  �͹���һ��������Ӧlistener�ÿ���  ���ǽ����  �϶����� �������  ��֪��ô��
	private volatile  Point oldpoint;


	static {
		BtnColro   = new Color(214,217,223);
	}
	JFrame frame ;
	//����������  ������JFrame  �ڼ������� �� JFrame����
	public Btn_JTXMouseMotionListener(JFrame frame) {
		this.frame = frame;
	
	}



	@Override
	public void mousePressed(MouseEvent e) {
		//System.out.println("pressed�¼�");
		 oldpoint = e.getPoint();
		  //  System.out.println(oldpoint.x);
	}
	@Override
	public void mouseClicked(MouseEvent e) {
	     
	  Object ob = e.getSource();
		 if(ob instanceof  JButton) {
			   JButton btn =(JButton) ob;
			   
			   if(btn.getText().equals("x")&&e.getClickCount()==1)
			   {
				   try {
					   if(JOptionPane.OK_OPTION==JOptionPane.showConfirmDialog(frame, " ȷ �� Ҫ �� �� �� ? ", "����", JOptionPane.OK_CANCEL_OPTION))
						    System.exit(0);
				   }catch(NullPointerException e1) {
					   JOptionPane.showMessageDialog(frame, "�������д��󣡣�", "�쳣", ImageObserver.ERROR);
				   }
					  		
			    
			   }		   
              if(btn.getText().equals("��")&&e.getClickCount()==1) {
            	  frame.setExtendedState(Frame.ICONIFIED);
              }
		}

		 
	}
	
	
	
	
	//��ק�¼�   ��  �����     ������    ����   ���Ե��û�д��¼�����
	@Override
	public void mouseDragged(MouseEvent e) {
		//������ק ����ǰ(��¼�����cursor����)��(�϶�e��������)����֮��ľ���仯   ����λ�ü�������仯���� ���
		if(e.getSource() instanceof   JLabel) {
		//	System.out.println("DFjdkf");
		//	System.out.print(true);
			int left =  frame.getLocation().x;  
			int top = frame.getLocation().y;
		//System.out.println("oldpoint  "+oldpoint);
//		System.out.println("new  "+e.getPoint());
//		System.out.println("��ק�¼�");
	         frame.setLocation(left+e.getX()-oldpoint.x,top+e.getY()-oldpoint.y);
		//	oldpoint=e.getPoint();
		//	System.out.println(frame.getLocation().getX()+"         "+e.getPoint().getX());
		}
	
				
	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		
		Object ob = e.getSource();
		if(ob instanceof  JButton) {
			   JButton btn =(JButton) ob;
			   if(btn.getText().equals("x"))
			   {
				   btn.setBackground(Color.RED);
				   btn.setForeground(Color.white);
			   }
			   
			   else  {
				   btn.setBackground(Color.blue);
				   btn.setForeground(Color.white);
			   }
		}
		
	}
	
	@Override
	public void mouseExited(MouseEvent e) {
	
		Object ob = e.getSource();
		if(ob instanceof  JButton) {
			   JButton btn =(JButton) ob;
			   if(btn.getText().equals("x"))
			   {
				   btn.setBackground(BtnColro);
				   btn.setForeground(Color.red);
			   }
			   
			   else {
				   btn.setBackground(BtnColro);
				   btn.setForeground(Color.blue);
			       }
			   }
		}
		

}


//class paintJLabel extends JLabel{
//	/**
//	 * 
//	 */
//	private static final long serialVersionUID = 4322544740556670820L;
//	
//	
//	private Image img2 =Toolkit.getDefaultToolkit().getImage("src/imgs/back.jpg").getScaledInstance(800,600,Image.SCALE_SMOOTH);
//	
//	public void  paintComponent(Graphics g) {
//		this.setLayout(null);
//		this.setOpaque(true);
//		if(img2!=null)
//		{
//			g.drawImage(img2, 0, 0, null);
//		
//		}
//	}	
//}
